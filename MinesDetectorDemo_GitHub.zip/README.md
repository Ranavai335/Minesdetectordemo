# MinesDetectorDemo (Colab-ready)

এই প্রজেক্টে Mines Detector এর জন্য একটি ডেমো Android অ্যাপ এবং Colab নোটবুক দেওয়া আছে।

## 🚀 APK বানানোর ধাপ

1. Google Colab ওপেন করুন।
2. `colab_build.ipynb` ফাইল ওপেন করুন।
3. প্রতিটি সেল রান করুন।
4. শেষে `/content/minesdetector/app/build/outputs/apk/debug/app-debug.apk` ডাউনলোড করুন।

## 📦 ফাইলসমূহ
- app/ → Android সোর্স
- mines_cnn.tflite → ডেমো ML মডেল
- colab_build.ipynb → APK বিল্ড স্ক্রিপ্ট
